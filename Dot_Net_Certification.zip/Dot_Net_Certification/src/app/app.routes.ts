import { ExtraOptions, RouterModule, Routes } from '@angular/router';
import { MainPagesComponent } from './main-pages/main-pages/main-pages.component';
import { QuestionPageComponent } from './question-page/question-page.component';
import { UserInfoComponent } from './user-info/user-info.component';
import { HomeComponent } from './home/home.component';
import { TestPassComponent } from './test-pass/test-pass.component';
import { CertificateComponent } from './certificate/certificate.component';
import { NgModule } from '@angular/core';
import { ContactUsComponent } from './contact-us/contact-us.component';

export const routes: Routes = [
    {path:'',component:HomeComponent},
    {path:'questions',component:QuestionPageComponent},
    {path:'user-info',component:UserInfoComponent},
    {path:'test-pass',component:TestPassComponent},
    {path:'certificate',component:CertificateComponent},
    {path:'contact-us',component:ContactUsComponent}
];


const routerOptions: ExtraOptions = {
    scrollPositionRestoration: 'top', // ✅ automatically scrolls to top on route change
    anchorScrolling: 'enabled'        // optional: allows anchor links to scroll
};

@NgModule({
    imports: [RouterModule.forRoot(routes, routerOptions)],
    exports: [RouterModule]
})
export class AppRoutingModule { }