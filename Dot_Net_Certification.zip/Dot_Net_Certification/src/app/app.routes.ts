import { Routes } from '@angular/router';
import { MainPagesComponent } from './main-pages/main-pages/main-pages.component';
import { QuestionPageComponent } from './question-page/question-page.component';

export const routes: Routes = [
    {path:'',component:MainPagesComponent},
    {path:'questions',component:QuestionPageComponent}
];
