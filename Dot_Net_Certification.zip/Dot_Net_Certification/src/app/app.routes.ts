import { Routes } from '@angular/router';
import { MainPagesComponent } from './main-pages/main-pages/main-pages.component';
import { QuestionPageComponent } from './question-page/question-page.component';
import { UserInfoComponent } from './user-info/user-info.component';
import { HomeComponent } from './home/home.component';

export const routes: Routes = [
    {path:'',component:HomeComponent},
    {path:'questions',component:QuestionPageComponent},
    {path:'user-info',component:UserInfoComponent}
];
