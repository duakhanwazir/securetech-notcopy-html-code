import { NgIf } from '@angular/common';
import { Component } from '@angular/core';
import { Router, RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-home',
  imports: [NgIf,RouterLink,RouterOutlet,RouterLinkActive],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent {

  showPopup = false;

  constructor(private router: Router) {}

openPopup() {
  this.showPopup = true;
}

confirm() {
  this.router.navigate(['/user-info']);
  this.showPopup = false;
}

cancel() {
  this.showPopup = false;
  window.scrollBy({
    top: 200,
    behavior: 'smooth'
  });
}

  
}
