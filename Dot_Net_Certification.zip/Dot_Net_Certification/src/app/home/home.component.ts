import { NgIf } from '@angular/common';
import { Component } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-home',
  imports: [NgIf,RouterLink,RouterOutlet,RouterLinkActive],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent {

  showPopup = false;

openPopup() {
  this.showPopup = true;
}

confirm() {
  console.log("User confirmed.");
  this.showPopup = false;
}

cancel() {
  this.showPopup = false;
  window.scrollBy({
    top: 200,
    behavior: 'smooth'
  });
}

  
}
