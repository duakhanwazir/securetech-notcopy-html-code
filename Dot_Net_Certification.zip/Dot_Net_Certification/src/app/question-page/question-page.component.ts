import { Component } from '@angular/core';

@Component({
  selector: 'app-question-page',
  templateUrl: './question-page.component.html',
  styleUrls: ['./question-page.component.css']
})
export class QuestionPageComponent {

  // This function will be triggered when a user selects a file for the front, right, or left face
  openCamera(event: Event, inputId: string): void {
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' } })
        .then((stream) => {
          // If the camera is available, show the camera feed
          let video = document.createElement('video');
          video.srcObject = stream;
          video.play();

          // Open the camera feed in a popup
          let videoPopup = window.open('', 'Camera Feed', 'width=640,height=480');
          
          // Null check for videoPopup
          if (videoPopup) {
            videoPopup.document.body.appendChild(video);
            videoPopup.document.title = 'Camera Feed';

            // Stop the camera after it's used
            video.onloadedmetadata = function () {
              videoPopup.document.body.appendChild(video);
              videoPopup.focus();
            };
          } else {
            // If the popup couldn't be opened, show an error message
            alert("Unable to open camera feed. Please check if popups are blocked.");
          }
        })
        .catch((err) => {
          // If camera is not available, show error message
          document.getElementById('camera-error-message')!.style.display = 'block';
        });
    } else {
      // If the browser does not support getUserMedia
      document.getElementById('camera-error-message')!.style.display = 'block';
    }
  }
}
