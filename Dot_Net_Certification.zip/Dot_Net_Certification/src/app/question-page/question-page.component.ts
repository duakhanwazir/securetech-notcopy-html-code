import { Component, OnInit, AfterViewInit, Renderer2 } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-question-page',
  templateUrl: './question-page.component.html',
  styleUrls: ['./question-page.component.css']
})
export class QuestionPageComponent implements OnInit, AfterViewInit {
  constructor(private renderer: Renderer2,private router:Router) {}

  totalSeconds = 7 * 60;
  timerInterval: any;

  ngOnInit(): void {}

  ngAfterViewInit(): void {
    this.createParticles();
    this.updateWatch();
    this.timerInterval = setInterval(() => this.updateWatch(), 1000);
    this.setupOptionListeners();
    this.setupSubmitListener();
  }

  createParticles(): void {
    const particlesContainer = document.getElementById('particles');
    for (let i = 0; i < 30; i++) {
      const particle = this.renderer.createElement('div');
      particle.classList.add('particle');

      const size = Math.random() * 10 + 5;
      particle.style.width = `${size}px`;
      particle.style.height = `${size}px`;
      particle.style.left = `${Math.random() * 100}%`;
      particle.style.top = `${Math.random() * 100}%`;
      particle.style.animationDuration = `${Math.random() * 20 + 10}s`;
      particle.style.animationDelay = `${Math.random() * 5}s`;

      particlesContainer?.appendChild(particle);
    }
  }

  updateWatch(): void {
    const minutes = Math.floor(this.totalSeconds / 60);
    const seconds = this.totalSeconds % 60;

    const timeElement = document.getElementById('time');
    const hourHand = document.querySelector('.hour-hand') as HTMLElement;
    const minuteHand = document.querySelector('.minute-hand') as HTMLElement;
    const secondHand = document.querySelector('.second-hand') as HTMLElement;

    if (timeElement) {
      timeElement.textContent = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
    }

    const hoursDegrees = ((minutes / 60) * 360) + 90;
    const minsDegrees = ((minutes % 60) / 60) * 360 + 90;
    const secsDegrees = ((seconds % 60) / 60) * 360 + 90;

    hourHand.style.transform = `rotate(${hoursDegrees}deg)`;
    minuteHand.style.transform = `rotate(${minsDegrees}deg)`;
    secondHand.style.transform = `rotate(${secsDegrees}deg)`;

    if (this.totalSeconds <= 60) {
      if (timeElement) {
        timeElement.style.color = '#ff5555';
        timeElement.style.textShadow = '0 0 10px rgba(255, 85, 85, 0.8)';
      }
      document.querySelector('.watch-face')?.setAttribute('style', 'box-shadow: inset 0 0 20px rgba(255, 0, 0, 0.5)');
      secondHand.style.background = '#ff5555';
    } else if (this.totalSeconds <= 180) {
      if (timeElement) {
        timeElement.style.color = '#ffff55';
        timeElement.style.textShadow = '0 0 10px rgba(255, 255, 85, 0.8)';
      }
      secondHand.style.background = '#ffff55';
    }

    if (this.totalSeconds <= 0) {
      clearInterval(this.timerInterval);
      if (timeElement) timeElement.textContent = '00:00';
      (document.getElementById('submitBtn') as HTMLElement)?.click();
    } else {
      this.totalSeconds--;
    }
  }

  setupOptionListeners(): void {
    const options = document.querySelectorAll('.option');
    let selectedOption: Element | null = null;

    options.forEach(option => {
      option.addEventListener('click', function () {
        if (selectedOption) return;

        selectedOption = option;
        option.classList.add('selected');
        (option as HTMLElement).style.pointerEvents = 'none';

        options.forEach(opt => {
          if (opt !== option) {
            (opt as HTMLElement).style.opacity = '0.6';
            (opt as HTMLElement).style.pointerEvents = 'none';
            (opt as HTMLElement).style.transform = 'scale(0.98)';
          }
        });

        const submitBtn = document.getElementById('submitBtn') as HTMLButtonElement;
        if (submitBtn) submitBtn.disabled = false;

        setTimeout(() => {
          (option as HTMLElement).style.transform = 'translateY(-5px) scale(1.02)';
        }, 10);
      });
    });
  }

  setupSubmitListener(): void {
    const submitBtn = document.getElementById('submitBtn') as HTMLButtonElement;
    
    submitBtn.addEventListener('click', () => {
      if (submitBtn.disabled) return;
  
      // Disable and show submitting state
      submitBtn.disabled = true;
      submitBtn.innerHTML = '<span class="btn-text">Submitting...</span>';
  
      // Show confetti animation
      this.createConfetti();
  
      // After animation ends (1.5s), update UI and navigate
      setTimeout(() => {
        submitBtn.innerHTML = '<span class="btn-text">Submitted!</span>';
        submitBtn.style.background = 'linear-gradient(45deg, var(--success), #55ff55)';
        
        clearInterval(this.timerInterval);
  
        // Navigate after short delay for effect (optional)
        setTimeout(() => {
          this.navigateToTestPass(); // 🚀 Navigate to next page
        }, 500); // You can increase delay if needed
      }, 1500); // Wait for confetti effect
    });
  }
  

  navigateToTestPass(): void {
    this.router.navigate(['/test-pass']).then(()=>{
      window.scrollTo({top:0,behavior:'smooth'});
    });
  }
  

  createConfetti(): void {
    const confettiContainer = document.getElementById('confetti-container');
    const colors = ['#ff0000', '#00ff00', '#0000ff', '#ffff00', '#ff00ff', '#00ffff'];

    for (let i = 0; i < 150; i++) {
      const confetti = this.renderer.createElement('div');
      confetti.classList.add('confetti');

      const color = colors[Math.floor(Math.random() * colors.length)];
      const size = Math.random() * 10 + 5;
      const shape = Math.random() > 0.5 ? '50%' : '0';

      confetti.style.backgroundColor = color;
      confetti.style.width = `${size}px`;
      confetti.style.height = `${size}px`;
      confetti.style.borderRadius = shape;
      confetti.style.left = `${Math.random() * 100}%`;
      confetti.style.top = `-10px`;

      const duration = Math.random() * 3 + 2;
      const delay = Math.random() * 2;

      confetti.style.animation = `confettiFall ${duration}s ease-in ${delay}s forwards`;

      confettiContainer?.appendChild(confetti);
      setTimeout(() => confetti.remove(), (duration + delay) * 1000);
    }

    const style = this.renderer.createElement('style');
    style.textContent = `
      @keyframes confettiFall {
        0% { transform: translateY(0) rotate(0deg); opacity: 1; }
        100% { transform: translateY(100vh) rotate(360deg) translateX(${Math.random() > 0.5 ? '' : '-'}${Math.random() * 200}px); opacity: 0; }
      }
    `;
    document.head.appendChild(style);
  }
}
