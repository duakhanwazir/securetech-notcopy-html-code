import { NgIf } from '@angular/common';
import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  imports:[NgIf],
  selector: 'app-user-info',
  templateUrl: './user-info.component.html',
  styleUrls: ['./user-info.component.css']
})
export class UserInfoComponent {
  isLoading = false; // Variable to track loading state

  constructor(private router: Router) {}

  previewImage(event: Event, side: string) {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files[0]) {
      const reader = new FileReader();
      
      reader.onload = (e: any) => {
        const previewImg = document.getElementById(`${side}-preview-img`) as HTMLImageElement;
        const previewContainer = document.getElementById(`${side}-preview`);
        
        if (previewImg && previewContainer) {
          previewImg.src = e.target.result;
          previewImg.style.display = 'block';
          
          // Hide the default text
          const span = previewContainer.querySelector('span');
          if (span) {
            span.style.display = 'none';
          }
        }
      };
      
      reader.readAsDataURL(input.files[0]);
    }
  }

  navigateToquestion() {
    this.isLoading = true;
    this.router.navigate(['questions']).then(() => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
      this.isLoading = false;
    });
  }  
}
