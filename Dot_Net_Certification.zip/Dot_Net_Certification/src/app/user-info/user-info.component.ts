import { Component } from '@angular/core';

@Component({
  selector: 'app-user-info',
  imports: [],
  templateUrl: './user-info.component.html',
  styleUrl: './user-info.component.css'
})
export class UserInfoComponent {
  previewImage(event: Event, side: string) {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files[0]) {
      const reader = new FileReader();
      
      reader.onload = (e: any) => {
        const previewImg = document.getElementById(`${side}-preview-img`) as HTMLImageElement;
        const previewContainer = document.getElementById(`${side}-preview`);
        
        if (previewImg && previewContainer) {
          previewImg.src = e.target.result;
          previewImg.style.display = 'block';
          
          // Hide the default text
          const span = previewContainer.querySelector('span');
          if (span) {
            span.style.display = 'none';
          }
        }
      };
      
      reader.readAsDataURL(input.files[0]);
    }
  }
}