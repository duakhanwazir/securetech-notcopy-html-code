import { Component } from '@angular/core';

@Component({
  selector: 'app-test-fail',
  imports: [],
  templateUrl: './test-fail.component.html',
  styleUrl: './test-fail.component.css'
})
export class TestFailComponent {

}
