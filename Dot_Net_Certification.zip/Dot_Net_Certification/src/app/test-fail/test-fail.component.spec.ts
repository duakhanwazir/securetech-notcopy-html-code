import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TestFailComponent } from './test-fail.component';

describe('TestFailComponent', () => {
  let component: TestFailComponent;
  let fixture: ComponentFixture<TestFailComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TestFailComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TestFailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
