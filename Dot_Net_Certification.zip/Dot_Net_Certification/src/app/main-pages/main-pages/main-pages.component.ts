import { Component } from '@angular/core';
import { HeaderComponent } from '../../layout/header/header.component';
import { HomeComponent } from '../../home/home.component';
import { FooterComponent } from '../../layout/footer/footer.component';

@Component({
  selector: 'app-main-pages',
  imports: [HeaderComponent,HomeComponent,FooterComponent],
  templateUrl: './main-pages.component.html',
  styleUrl: './main-pages.component.css'
})
export class MainPagesComponent {

}
