import { Component, ChangeDetectorRef } from '@angular/core';
import { Router } from '@angular/router';
import html2pdf from 'html2pdf.js';
import { CertificateService } from '../services/certificate.service';
import { CertificateComponent } from '../certificate/certificate.component';
import { NgIf } from '@angular/common';

@Component({
  selector: 'app-test-pass',
  standalone: true,
  imports: [CertificateComponent, NgIf],
  templateUrl: './test-pass.component.html',
  styleUrl: './test-pass.component.css'
})
export class TestPassComponent {
  user = {
    picurl: 'https://th.bing.com/th/id/OIP.leRaZskYpTKA55a0St0tZgHaJa?rs=1&pid=ImgDetMain',
    name: 'Muhammad Junaid',
    Date: '7/2/2025',
    certificate: '123456789',
    obtaindmarks: 9
  };

  download = false;
  isDownloading = false;

  constructor(
    private router: Router,
    private certService: CertificateService,
    private cdRef: ChangeDetectorRef
  ) {}

  downloadCertificate() {
    if (this.isDownloading) return; // prevent re-entry
  
    this.certService.setUserData(this.user);
    this.isDownloading = true;
    this.download = true;
    this.cdRef.detectChanges();
  
    let pdfGenerated = false;
  
    setTimeout(() => {
      if (pdfGenerated) return;
      const element = document.getElementById('certificate-download');
  
      if (element) {
        const opt = {
          margin: 0,
          filename: `${this.user.name}.pdf`,
          image: { type: 'jpeg', quality: 0.98 },
          html2canvas: { scale: 2 },
          jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
        };
  
        html2pdf()
          .from(element)
          .set(opt)
          .save()
          .then(() => {
            pdfGenerated = true; // prevent future downloads
            this.isDownloading = false;
            this.download = false;
            this.cdRef.detectChanges();
          });
      }
    }, 300);
  }
  NavigateToContactus(): void {
    this.router.navigate(['contact-us']).then(() => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }
  
}
