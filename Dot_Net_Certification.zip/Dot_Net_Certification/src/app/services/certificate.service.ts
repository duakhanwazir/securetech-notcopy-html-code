import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CertificateService {
  private userData: any;

  setUserData(data: any) {
    this.userData = data;
    console.log("set data called "+this.userData.name);
  }

  getUserData() {
    return this.userData;
  }
}
